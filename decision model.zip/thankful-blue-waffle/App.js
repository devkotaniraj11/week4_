import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Button } from 'react-native-paper';

export default function App() {
  const [modalVisible, setModalVisible] = useState(false);
  const [count, setCount] = useState(0);

  const handleIncreaseCount = () => {
    setCount(prev => prev + 1);
  };

  return (
    <View style={styles.container}>

      {/* Button to open modal */}
      <Button 
        mode="contained" 
        onPress={() => setModalVisible(true)} 
        style={styles.openBtn}
        labelStyle={styles.btnLabel}
      >
        Open Modal
      </Button>

      {/* Modal */}
      {modalVisible && (
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Decision Model</Text>
            <Text style={styles.modalText}>Count: {count}</Text>

            <View style={styles.modalButtons}>
              <Button 
                mode="outlined" 
                onPress={() => setModalVisible(false)} 
                style={styles.modalBtn}
                labelStyle={styles.btnLabel}
              >
                Close
              </Button>

              <Button 
                mode="contained" 
                onPress={handleIncreaseCount} 
                style={styles.modalBtn}
                labelStyle={styles.btnLabel}
              >
                Increase
              </Button>
            </View>
          </View>
        </View>
      )}

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E6EEF5',
    justifyContent: 'center',
    alignItems: 'center',
  },

  openBtn: {
    borderRadius: 12,
    paddingHorizontal: 20,
    paddingVertical: 6,
    backgroundColor: '#2C3A47',
  },

  btnLabel: {
    fontSize: 14,
    fontWeight: '600',
  },

  modalOverlay: {
    position: 'absolute',
    inset: 0,
    backgroundColor: 'rgba(0,0,0,0.40)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  modalContent: {
    width: '82%',
    padding: 25,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.95)',
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
    elevation: 10,
    alignItems: 'center',
  },

  modalTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#2C3A47',
    marginBottom: 10,
  },

  modalText: {
    fontSize: 18,
    color: '#2C3A47',
    marginBottom: 20,
  },

  modalButtons: {
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
  },

  modalBtn: {
    flex: 1,
    marginHorizontal: 5,
    borderRadius: 12,
  },
});
